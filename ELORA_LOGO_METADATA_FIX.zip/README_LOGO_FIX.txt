ELORA logo/search preview fix
- Added favicon.ico and favicon.png
- Added icon metadata and social preview metadata in index.html
- Google may take time to recrawl and update the search result logo; this cannot be forced from the website files alone.
